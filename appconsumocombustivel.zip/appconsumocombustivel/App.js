import React, {useState} from 'react';
import { Text, SafeAreaView, StyleSheet, View, TextInput, TouchableOpacity } from 'react-native';

export default function App() {

  function CalcularCombustivel(){
  const resultado = km / combustivel;
  alert('O comsumo por litro do seu carro é ' + resultado)
}

    const [km, setKm] = useState('');
    const [combustivel, setCombustivel] = useState('');
  
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Consumo de Combustivel
      </Text>
      <TextInput style={styles.input} 
      placeholder='Insira a distancia percorrida: '
      placeholderTextColor='#000'
      keyboardType='numeric'
      onChangeText={(km)=>setKm(km)}
      />

        
      <TextInput style={styles.input}
      placeholder='Insira o consumo do seu carro: '
      placeholderTextColor='#000'
      keyboardType='numeric'
      onChangeText={(combustivel)=>setCombustivel(combustivel)}
      />


      <TouchableOpacity style={styles.btn} onPress={CalcularCombustivel}>
        <Text style={styles.textbtn}> Calcular o Consumo </Text>
      </TouchableOpacity>
      

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom:60
  },

  btn:{
    alignItems: 'center',
    backgroundColor:'#000',
    padding:15,
    borderRadius:10,
    margin:15,
    marginTop:50,
  },
  textbtn:{
    fontSize:30,
    color:'#fff'
  },
  input:{
    fontSize:18,
    padding:20,
    backgroundColor:'#a0c2',
    borderRadius:10,
    margin:15,
    
  }
});
